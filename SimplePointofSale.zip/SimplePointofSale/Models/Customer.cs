﻿using System.Collections.Generic;

namespace SimplePointofSale.Models
{
    public class Customer
    {
        public int ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Email { get; set; }

        public virtual ICollection<Invoice> Invoices { get; set; }
    }
}